// #pragma once 컴파일러상의 작동 오류로 아래 코드로 대체
#include "power.c"

double power(int x, int y);