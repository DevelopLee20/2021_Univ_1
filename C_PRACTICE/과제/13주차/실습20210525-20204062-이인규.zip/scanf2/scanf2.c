#include <stdio.h>

int main(void){

    int d, o, x;

    scanf("%d %o %x", &d, &o, &x);       // 10진수, 8진수, 16진수 입력
    printf("d=%d o=%d x=%d\n", d, o, x); // 10진수, 8진수, 16진수 출력

    return 0;
}